package edu.ncsu.monopoly;

public interface RespondDialog {
    boolean getResponse();
}

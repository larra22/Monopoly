package edu.ncsu.monopoly.gui;

import edu.ncsu.monopoly.Cell;

public interface CellInfoFormatter {
    public String format(Cell cell);
}
